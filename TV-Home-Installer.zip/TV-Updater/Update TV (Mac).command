#!/bin/bash
# TV Updater for Mac (also works on Linux). Double-click this file to run it.
# It connects to the Android TV over Wi-Fi, removes the apps listed in
# remove-these-apps.txt, installs/updates the .apk files in the "apps" folder,
# and sets the new home screen. Everything it does can be undone (option 2).

cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"
SETTINGS="$ROOT/settings.txt"
BLOAT_LIST="$ROOT/remove-these-apps.txt"
APPS_DIR="$ROOT/apps"
BACKUPS="$ROOT/backups"
TOOLS="$ROOT/updater"
REMOVED_LOG="$BACKUPS/removed-apps.txt"
DISABLED_LOG="$BACKUPS/disabled-launchers.txt"
HOME_LOG="$BACKUPS/original-home-screen.txt"
RUN_LOG="$BACKUPS/update-log.txt"
mkdir -p "$BACKUPS" "$APPS_DIR" "$TOOLS"
touch "$REMOVED_LOG"

ADB=""
SERIAL=""
STATE=""

# ---------- messages ----------
log()  { printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$RUN_LOG"; }
say()  { printf '%s\n' "$*"; }
ok()   { printf '  \033[32m[OK]\033[0m %s\n' "$*"; log "OK    $*"; }
warn() { printf '  \033[33m[!]\033[0m  %s\n' "$*"; log "WARN  $*"; }
fail() { printf '  \033[31m[X]\033[0m  %s\n' "$*"; log "FAIL  $*"; }
step() { printf '\n\033[1m%s\033[0m\n' "$*"; }

# ---------- settings.txt ----------
get_setting() {
  [ -f "$SETTINGS" ] || return 0
  grep -E "^[[:space:]]*$1[[:space:]]*=" "$SETTINGS" | tail -n 1 | cut -d= -f2- \
    | tr -d '\r' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'
}

# The app that becomes the Home screen: HOME_SCREEN_APP, or TV Home itself when that's blank
# and TV Home is in the apps folder.
get_home_app() {
  local h; h="$(get_setting HOME_SCREEN_APP)"
  if [ -n "$h" ]; then printf '%s' "$h"; return; fi
  if ls "$APPS_DIR"/*TVHome*.apk >/dev/null 2>&1; then printf 'app.tvhome'; fi
}

set_setting() {
  local key="$1" value="$2" tmp="$SETTINGS.tmp"
  if grep -qE "^[[:space:]]*$key[[:space:]]*=" "$SETTINGS" 2>/dev/null; then
    awk -v k="$key" -v v="$value" '{
      line = $0; sub(/\r$/, "", line)
      name = line; sub(/=.*/, "", name); gsub(/^[ \t]+|[ \t]+$/, "", name)
      if (index(line, "=") > 0 && name == k) print k "=" v; else print $0
    }' "$SETTINGS" > "$tmp" && mv "$tmp" "$SETTINGS"
  else
    if [ -s "$SETTINGS" ] && [ -n "$(tail -c 1 "$SETTINGS")" ]; then echo >> "$SETTINGS"; fi
    printf '%s=%s\n' "$key" "$value" >> "$SETTINGS"
  fi
}

# One package name per line; ignores blank lines, comments and Windows line endings.
read_list() {
  [ -f "$1" ] || return 0
  sed -e 's/#.*//' -e 's/\r//g' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' "$1" | grep -v '^$'
}

# ---------- safety checks ----------
valid_package() {
  printf '%s' "$1" | grep -qE '^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$'
}

valid_address() {
  printf '%s' "$1" | grep -qE '^[0-9]{1,3}(\.[0-9]{1,3}){3}(:[0-9]{1,5})?$'
}

# Never remove anything the TV needs to work, even if it's on the list.
is_protected() {
  local p
  p="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
  case "$p" in
    android|com.android.shell|com.android.tv|com.android.vending|com.google.android.gms|com.google.android.gsf)
      return 0 ;;
    *launcher*|*inputmethod*|*keyboard*|*setupwizard*|*setupwraith*|*provision*|*tvinput*|*tv.input*|*hdmi*|*cec*|*tuner*|*remote*|*bluetooth*|*systemui*|*settings*|*providers*|*packageinstaller*|*permissioncontroller*|*webview*|*framework*|*mediatek*|*.mtk*|*amlogic*|*droidlogic*|*realtek*)
      return 0 ;;
  esac
  local home
  home="$(get_home_app)"
  [ -n "$home" ] && [ "$p" = "$(printf '%s' "$home" | tr '[:upper:]' '[:lower:]')" ] && return 0
  return 1
}

# ---------- adb ----------
find_adb() {
  if [ -x "$TOOLS/platform-tools/adb" ]; then ADB="$TOOLS/platform-tools/adb"; return 0; fi
  if command -v adb >/dev/null 2>&1; then ADB="$(command -v adb)"; return 0; fi
  download_adb
}

download_adb() {
  local os url zip
  case "$(uname -s)" in
    Darwin) os=darwin ;;
    Linux)  os=linux ;;
    *) fail "This computer isn't a Mac. Use 'Update TV (Windows).bat' instead."; return 1 ;;
  esac
  url="https://dl.google.com/android/repository/platform-tools-latest-$os.zip"
  zip="$TOOLS/platform-tools.zip"
  say "  Downloading the Android tools from Google (one time only)..."
  if ! curl -fL --progress-bar -o "$zip" "$url"; then
    rm -f "$zip"
    fail "The download failed. Check the internet connection and try again."
    return 1
  fi
  rm -rf "$TOOLS/platform-tools"
  if ! unzip -q -o "$zip" -d "$TOOLS"; then
    rm -f "$zip"
    fail "Couldn't unpack the Android tools."
    return 1
  fi
  rm -f "$zip"
  chmod +x "$TOOLS/platform-tools/adb" 2>/dev/null
  xattr -dr com.apple.quarantine "$TOOLS/platform-tools" 2>/dev/null
  ADB="$TOOLS/platform-tools/adb"
  ok "Android tools ready"
}

# </dev/null stops adb from swallowing the list being read in a loop.
adb_tv() { "$ADB" -s "$SERIAL" "$@" </dev/null 2>&1 | tr -d '\r'; }

device_state() {
  "$ADB" devices 2>/dev/null | tr -d '\r' | awk -v s="$1" '$1 == s { print $2 }'
}

network_name() { case "$1" in ethernet) printf 'an Ethernet cable' ;; *) printf 'Wi-Fi' ;; esac; }

ask_network() {
  local c
  say ""
  say "  How is the TV connected to the internet?"
  say "    1) Wi-Fi"
  say "    2) Ethernet cable"
  read -r -p "  Choose 1 or 2: " c
  case "$c" in
    2) set_setting TV_NETWORK ethernet ;;
    1) set_setting TV_NETWORK wifi ;;
    *) [ -n "$(get_setting TV_NETWORK)" ] || set_setting TV_NETWORK wifi ;;
  esac
  ok "Saved: the TV uses $(network_name "$(get_setting TV_NETWORK)")"
}

# Which network the connected TV is really using: wifi, ethernet or nothing.
detect_network() {
  local line
  line="$(adb_tv shell ip -o -4 addr show | grep -F " ${SERIAL%%:*}/" | head -n 1)"
  case "$line" in
    *eth*) printf 'ethernet' ;;
    *wlan*|*wifi*) printf 'wifi' ;;
  esac
}

ask_address() {
  local addr
  say ""
  say "  Type the TV's IP address. Find it on the TV under"
  if [ "$(get_setting TV_NETWORK)" = "ethernet" ]; then
    say "  Settings > Network & Internet > Ethernet. It looks like 192.168.1.23"
  else
    say "  Settings > Network & Internet > (your Wi-Fi name). It looks like 192.168.1.23"
  fi
  while true; do
    read -r -p "  TV address: " addr
    addr="$(printf '%s' "$addr" | tr -d '[:space:]')"
    [ -z "$addr" ] && return 1
    if valid_address "$addr"; then set_setting TV_IP "$addr"; ok "Saved the TV address"; return 0; fi
    warn "That doesn't look right. It should be 4 numbers with dots, like 192.168.1.23"
  done
}

pair_tv() {
  local paddr pcode caddr
  say ""
  say "  On the TV: Developer options > Wireless debugging > Pair device with pairing code."
  read -r -p "  Type the IP address and port shown under the code (like 192.168.1.23:37123): " paddr
  read -r -p "  Type the 6-digit code: " pcode
  paddr="$(printf '%s' "$paddr" | tr -d '[:space:]')"
  pcode="$(printf '%s' "$pcode" | tr -d '[:space:]')"
  if ! valid_address "$paddr" || ! printf '%s' "$pcode" | grep -qE '^[0-9]{6}$'; then
    fail "That address or code doesn't look right."
    return 1
  fi
  if ! "$ADB" pair "$paddr" "$pcode" 2>&1 | tr -d '\r' | grep -qi 'success'; then
    fail "Pairing didn't work. The code changes each time, so try again with the new one."
    return 1
  fi
  ok "Paired with the TV"
  say "  Now look at the main Wireless debugging screen on the TV."
  read -r -p "  Type the IP address and port shown there (like 192.168.1.23:41234): " caddr
  caddr="$(printf '%s' "$caddr" | tr -d '[:space:]')"
  valid_address "$caddr" || { fail "That address doesn't look right."; return 1; }
  set_setting TV_IP "$caddr"
}

# This computer's home-network prefixes, like 192.168.1
local_prefixes() {
  if [ -n "$TV_UPDATER_SUBNETS" ]; then printf '%s\n' $TV_UPDATER_SUBNETS; return 0; fi
  { ifconfig 2>/dev/null; ip -4 addr 2>/dev/null; } \
    | awk '/inet / {print $2}' | sed -e 's#/.*##' -e 's/^addr://' \
    | grep -E '^(10|172|192)\.[0-9]+\.[0-9]+\.[0-9]+$' \
    | awk -F. '{print $1"."$2"."$3}' | sort -u | head -n 4
}

# Lists TVs that accept a connection: adb's network port 5555, plus newer TVs
# that announce "Wireless debugging". Takes about 2 seconds.
scan_network() {
  local tmp prefix i
  tmp="$(mktemp "${TMPDIR:-/tmp}/tvscan.XXXXXX")"
  for prefix in $(local_prefixes); do
    for i in $(seq 1 254); do
      ( exec 3<>"/dev/tcp/$prefix.$i/5555" && echo "$prefix.$i" >> "$tmp" ) 2>/dev/null &
    done
  done
  sleep 2
  kill $(jobs -p) 2>/dev/null
  wait 2>/dev/null
  "$ADB" mdns services 2>/dev/null | tr -d '\r' | grep '_adb-tls-connect' \
    | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:[0-9]+' >> "$tmp"
  sort -u "$tmp" | awk -F: '!seen[$1]++'
  rm -f "$tmp"
}

serial_for() { case "$1" in *:*) printf '%s' "$1" ;; *) printf '%s:5555' "$1" ;; esac; }

tv_label() {
  local serial="$1" name
  if [ "$(device_state "$serial")" = "device" ]; then
    name="$("$ADB" -s "$serial" shell settings get global device_name </dev/null 2>/dev/null | tr -d '\r')"
    if [ -z "$name" ] || [ "$name" = "null" ]; then
      name="$("$ADB" -s "$serial" shell getprop ro.product.model </dev/null 2>/dev/null | tr -d '\r')"
    fi
    printf '%s  (%s)' "$name" "${serial%:5555}"
  else
    printf 'Android TV at %s  (press Allow on that TV)' "${serial%:5555}"
  fi
}

# Finds TVs on the network and saves the one to use. Returns 1 if none found.
find_tv() {
  local found addr n i choice
  local -a list labels
  say "  Looking for TVs on your network (a few seconds)..."
  found="$(scan_network)"
  [ -z "$found" ] && return 1
  list=(); labels=()
  while IFS= read -r addr; do
    [ -z "$addr" ] && continue
    "$ADB" connect "$(serial_for "$addr")" >/dev/null 2>&1
    list[${#list[@]}]="$addr"
  done <<EOF
$found
EOF
  sleep 1
  for i in "${!list[@]}"; do labels[$i]="$(tv_label "$(serial_for "${list[$i]}")")"; done
  n=${#list[@]}
  if [ "$n" -eq 1 ]; then
    ok "Found ${labels[0]}"
    set_setting TV_IP "${list[0]}"
    return 0
  fi
  say ""
  say "  Found $n TVs:"
  for i in "${!list[@]}"; do say "    $((i+1))) ${labels[$i]}"; done
  while true; do
    read -r -p "  Which TV? (1-$n): " choice
    case "$choice" in
      ''|*[!0-9]*) ;;
      *) if [ "$choice" -ge 1 ] && [ "$choice" -le "$n" ]; then
           set_setting TV_IP "${list[$((choice-1))]}"
           ok "Using ${labels[$((choice-1))]}"
           return 0
         fi ;;
    esac
    warn "Type a number from 1 to $n"
  done
}

try_connect() {
  local i
  STATE=""
  for i in 1 2 3; do
    "$ADB" connect "$SERIAL" >/dev/null 2>&1
    STATE="$(device_state "$SERIAL")"
    [ -n "$STATE" ] && [ "$STATE" != "offline" ] && return 0
    "$ADB" disconnect "$SERIAL" >/dev/null 2>&1
    sleep 1
  done
  return 1
}

connect_tv() {
  local addr i choice
  find_adb || return 1
  "$ADB" start-server >/dev/null 2>&1

  while true; do
    STATE=""
    addr="$(get_setting TV_IP)"
    if [ -n "$addr" ]; then
      SERIAL="$(serial_for "$addr")"
      say "  Connecting to the TV at ${SERIAL%:5555}..."
      try_connect
    fi
    if [ -z "$STATE" ] || [ "$STATE" = "offline" ]; then
      if find_tv; then
        SERIAL="$(serial_for "$(get_setting TV_IP)")"
        try_connect
      fi
    fi

    if [ "$STATE" = "unauthorized" ] || [ "$STATE" = "authorizing" ]; then
      say ""
      say "  >> Look at the TV now. It should ask \"Allow USB debugging?\""
      say "     Tick \"Always allow from this computer\" and press OK."
      say "     (Waiting up to 2 minutes...)"
      for i in $(seq 1 60); do
        sleep 2
        STATE="$(device_state "$SERIAL")"
        [ "$STATE" = "device" ] && break
        [ -z "$STATE" ] && "$ADB" connect "$SERIAL" >/dev/null 2>&1
      done
    fi

    if [ "$STATE" = "device" ]; then
      ok "Connected to the TV"
      return 0
    fi

    say ""
    fail "Couldn't find a TV that's ready."
    say "  On the TV: turn on Developer options, then USB debugging"
    say "  (and Network debugging if it's there). See the Setup Guide."
    say "  The TV and this computer must be on the same home network."
    say ""
    say "    1) Look again"
    say "    2) Type the TV's IP address"
    say "    3) Pair using a code (newer TVs with 'Wireless debugging')"
    say "    4) Go back"
    read -r -p "  Choose 1-4: " choice
    case "$choice" in
      1) set_setting TV_IP "" ;;
      2) ask_address || return 1 ;;
      3) pair_tv || return 1 ;;
      *) return 1 ;;
    esac
  done
}

choose_tv() {
  find_adb || return 1
  "$ADB" start-server >/dev/null 2>&1
  find_tv || { warn "No TVs found. Check the TV is on and set up (see the Setup Guide)."; ask_address; }
}

# Saves the Wi-Fi/Ethernet choice on the TV for TV Home to read.
save_choices() {
  printf '{"tvNetwork":"%s","savedBy":"TV Updater","savedAt":"%s"}\n' \
    "$(get_setting TV_NETWORK)" "$(date '+%Y-%m-%dT%H:%M:%S')" > "$BACKUPS/tvhome-setup.json"
  adb_tv shell mkdir -p /sdcard/TVHome >/dev/null
  case "$(adb_tv push "$BACKUPS/tvhome-setup.json" /sdcard/TVHome/setup.json)" in
    *error*|*failed*) warn "Couldn't save the settings file on the TV. TV Home will ask instead." ;;
    *) ok "TV Home will set game streaming for $(network_name "$(get_setting TV_NETWORK)")" ;;
  esac
  if [ "$(get_setting TV_NETWORK)" = "wifi" ]; then
    say "  Tip: for smooth game streaming, use 5 GHz Wi-Fi or plug the TV in with a cable."
  fi
}

# Package name of whatever currently answers the Home button, or empty.
resolved_home() {
  adb_tv shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME \
    | tail -n 1 | sed -n 's#^\([A-Za-z0-9_.]*\)/.*#\1#p'
}

# ---------- the jobs ----------
do_update() {
  local model android net stamp installed pkg out removed=0 skipped=0 gone=0 changed=0 todo=0
  local apk name code existing ans home cur comp

  [ -n "$(get_setting TV_NETWORK)" ] || ask_network
  step "Step 1 of 6: Connecting"
  connect_tv || return 1
  model="$(adb_tv shell getprop ro.product.model)"
  android="$(adb_tv shell getprop ro.build.version.release)"
  ok "TV model: $model (Android $android)"
  net="$(detect_network)"
  if [ -n "$net" ] && [ "$net" != "$(get_setting TV_NETWORK)" ]; then
    warn "The TV is actually using $(network_name "$net"), so I've changed that setting."
    set_setting TV_NETWORK "$net"
  fi
  ok "The TV is connected by $(network_name "$(get_setting TV_NETWORK)")"
  log "---- Update started on $model (Android $android) at $SERIAL"

  step "Step 2 of 6: Backing up the app list"
  stamp="$(date +%Y-%m-%d_%H-%M-%S)"
  installed="$BACKUPS/apps-before-$stamp.txt"
  adb_tv shell pm list packages | sed -n 's/^package://p' | sort > "$installed"
  if [ ! -s "$installed" ]; then
    fail "Couldn't read the TV's app list, so nothing was changed."
    return 1
  fi
  ok "Saved a list of $(wc -l < "$installed" | tr -d ' ') apps to backups/apps-before-$stamp.txt"

  [ -n "$(read_list "$BLOAT_LIST")" ] && todo=1
  set -- "$APPS_DIR"/*.apk; [ -e "$1" ] && todo=1
  if [ "$todo" -eq 0 ]; then
    save_choices
    step "This TV is ready, but there's nothing to install yet"
    say "  The apps folder is empty and no junk apps are listed, so nothing on the TV was changed."
    say "  When you get the TV Home app (an .apk file), put it in the apps folder"
    say "  and run this again. It will install it and make it the home screen."
    log "---- Nothing to install yet"
    return 0
  fi

  step "Step 3 of 6: Removing junk apps"
  if [ -z "$(read_list "$BLOAT_LIST")" ]; then
    say "  No apps are listed in remove-these-apps.txt, so nothing to remove."
  else
    while IFS= read -r pkg; do
      if ! valid_package "$pkg"; then warn "Skipped \"$pkg\" - that isn't a valid app name"; skipped=$((skipped+1)); continue; fi
      if is_protected "$pkg"; then warn "Kept $pkg - the TV needs it"; skipped=$((skipped+1)); continue; fi
      if ! grep -qxF "$pkg" "$installed"; then gone=$((gone+1)); continue; fi
      out="$(adb_tv shell pm uninstall -k --user 0 "$pkg")"
      case "$out" in
        *Success*)
          ok "Removed $pkg"; removed=$((removed+1)); changed=1
          grep -qxF "$pkg" "$REMOVED_LOG" || printf '%s\n' "$pkg" >> "$REMOVED_LOG" ;;
        *) warn "Couldn't remove $pkg ($out)"; skipped=$((skipped+1)) ;;
      esac
    done <<EOF
$(read_list "$BLOAT_LIST")
EOF
    say "  Removed $removed, already gone $gone, skipped $skipped."
  fi

  step "Step 4 of 6: Installing and updating apps"
  set -- "$APPS_DIR"/*.apk
  if [ ! -e "$1" ]; then
    say "  There are no .apk files in the apps folder, so nothing to install."
  else
    for apk in "$@"; do
      name="$(basename "$apk")"
      say "  Installing $name (this can take a minute)..."
      out="$(adb_tv install -r -d "$apk")"
      case "$out" in
        *Success*) ok "Installed $name"; changed=1 ;;
        *)
          code="$(printf '%s' "$out" | grep -oE 'INSTALL_[A-Z_]+' | head -n 1)"
          case "$code" in
            INSTALL_FAILED_UPDATE_INCOMPATIBLE)
              existing="$(printf '%s' "$out" | sed -n 's/.*Existing package \([A-Za-z0-9_.]*\) signatures.*/\1/p' | head -n 1)"
              warn "$name was built on a different computer than the copy already on the TV."
              if [ -n "$existing" ] && valid_package "$existing"; then
                read -r -p "  Remove the old copy and install this one? Its settings, like the camera login, will need setting up again. (y/n): " ans
                case "$ans" in
                  y|Y|yes|YES)
                    adb_tv uninstall "$existing" >/dev/null
                    out="$(adb_tv install -r "$apk")"
                    case "$out" in *Success*) ok "Installed $name"; changed=1 ;; *) fail "Still couldn't install $name ($out)" ;; esac ;;
                  *) warn "Left the old copy of $name on the TV" ;;
                esac
              fi ;;
            INSTALL_FAILED_VERSION_DOWNGRADE) warn "The TV already has a newer version of $name, so it was kept." ;;
            INSTALL_FAILED_INSUFFICIENT_STORAGE) fail "The TV is out of space, so $name couldn't be installed." ;;
            INSTALL_FAILED_NO_MATCHING_ABIS) fail "$name wasn't built for this TV's processor." ;;
            INSTALL_FAILED_OLDER_SDK) fail "This TV's Android version is too old for $name." ;;
            *) fail "Couldn't install $name ($out)" ;;
          esac ;;
      esac
    done
  fi

  step "Step 5 of 6: Setting the home screen"
  home="$(get_home_app)"
  if [ -z "$home" ]; then
    say "  No home screen app is set in settings.txt, so this step was skipped."
  elif ! valid_package "$home"; then
    warn "HOME_SCREEN_APP in settings.txt isn't a valid app name, so this step was skipped."
  elif ! adb_tv shell pm list packages | grep -qxF "package:$home"; then
    warn "The home screen app ($home) isn't on the TV yet. Put its .apk in the apps folder."
  else
    # Lets the camera alerts appear over other apps.
    adb_tv shell appops set "$home" SYSTEM_ALERT_WINDOW allow >/dev/null
    [ "$home" = "app.tvhome" ] && { adb_tv shell cmd notification allow_listener app.tvhome/app.tvhome.MediaListener >/dev/null 2>&1 || true; }
    [ "$home" = "app.tvhome" ] && { adb_tv shell pm grant app.tvhome android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true; }
    [ "$home" = "app.tvhome" ] && { adb_tv shell appops set --uid app.tvhome MANAGE_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true; }
    [ "$home" = "app.tvhome" ] && { adb_tv shell pm grant app.tvhome android.permission.READ_LOGS >/dev/null 2>&1 || true; }
    adb_tv shell pm grant "$home" android.permission.READ_EXTERNAL_STORAGE >/dev/null
    adb_tv shell appops set "$home" REQUEST_INSTALL_PACKAGES allow >/dev/null
    adb_tv shell appops set "$home" MANAGE_EXTERNAL_STORAGE allow >/dev/null
    ok "Allowed camera alerts, USB drive access and self-updates"

    if [ ! -s "$HOME_LOG" ]; then
      cur="$(adb_tv shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1)"
      case "$cur" in
        android/*|"$home"/*) ;;
        *) printf '%s' "$cur" | grep -qE '^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$' && printf '%s\n' "$cur" > "$HOME_LOG" ;;
      esac
    fi

    comp="$(adb_tv shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME "$home" | tail -n 1)"
    if ! printf '%s' "$comp" | grep -qE '^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$'; then
      warn "Couldn't find a home screen inside $home. Press Home on the remote and pick it from the list."
    else
      adb_tv shell cmd package set-home-activity "'$comp'" >/dev/null
      if [ "$(resolved_home)" = "$home" ]; then
        ok "The new home screen is now the default"; changed=1
      else
        # Google TV / newer TVs keep their own launcher in front. Switch it off (one at a time) until TV Home wins.
        say "  This TV keeps its own home screen in front. Switching it off so TV Home can take over..."
        local hp just_disabled="" i=0
        while [ "$i" -lt 4 ]; do
          hp="$(resolved_home)"
          [ "$hp" = "$home" ] && break
          { [ -z "$hp" ] || [ "$hp" = "android" ]; } && break
          adb_tv shell pm disable-user --user 0 "$hp" >/dev/null
          just_disabled="$just_disabled $hp"
          grep -qxF "$hp" "$DISABLED_LOG" 2>/dev/null || printf '%s\n' "$hp" >> "$DISABLED_LOG"
          adb_tv shell cmd package set-home-activity "'$comp'" >/dev/null
          i=$((i+1))
        done
        if [ "$(resolved_home)" = "$home" ]; then
          ok "TV Home is now the home screen"; changed=1
        else
          # Rollback: switch back on anything we just disabled, so the TV keeps a working home screen.
          for hp in $just_disabled; do adb_tv shell pm enable "$hp" >/dev/null; grep -vxF "$hp" "$DISABLED_LOG" > "$DISABLED_LOG.tmp" 2>/dev/null && mv "$DISABLED_LOG.tmp" "$DISABLED_LOG"; done
          warn "This TV wouldn't let TV Home take over the Home button, so its own home screen was kept. TV Home is still installed under Apps."
        fi
      fi
    fi
  fi

  step "Step 6 of 6: Saving your choices on the TV"
  save_choices

  if [ "$changed" -eq 1 ]; then
    step "All done!"
    say "  Press Home on the TV remote to see the result."
    say "  If anything looks wrong, run this again and choose 2) Undo."
  else
    step "Finished. Nothing on the TV needed changing."
  fi
  log "---- Update finished"
}

do_undo() {
  local pkg out kept home ans

  step "Undo: putting the TV back how it was"
  connect_tv || return 1
  log "---- Undo started at $SERIAL"

  if [ -s "$DISABLED_LOG" ]; then
    while IFS= read -r pkg; do
      [ -z "$pkg" ] && continue
      adb_tv shell pm enable "$pkg" >/dev/null
      ok "Switched $pkg back on"
    done < "$DISABLED_LOG"
    rm -f "$DISABLED_LOG"
  fi

  if [ -z "$(read_list "$REMOVED_LOG")" ]; then
    say "  This updater hasn't removed any apps, so there's nothing to put back."
  else
    kept="$REMOVED_LOG.tmp"; : > "$kept"
    while IFS= read -r pkg; do
      valid_package "$pkg" || continue
      out="$(adb_tv shell pm install-existing "$pkg")"
      case "$out" in
        *Failure*|*Error*|*error*|*exist*) warn "Couldn't put back $pkg ($out)"; printf '%s\n' "$pkg" >> "$kept" ;;
        *installed*|*Success*) ok "Put back $pkg" ;;
        *) warn "Couldn't put back $pkg ($out)"; printf '%s\n' "$pkg" >> "$kept" ;;
      esac
    done <<EOF
$(read_list "$REMOVED_LOG")
EOF
    mv "$kept" "$REMOVED_LOG"
  fi

  if [ -s "$HOME_LOG" ]; then
    out="$(adb_tv shell cmd package set-home-activity "'$(tr -d '\r\n' < "$HOME_LOG")'")"
    case "$out" in
      *Success*) ok "Switched back to the original home screen"; rm -f "$HOME_LOG" ;;
      *) warn "Couldn't switch the home screen back. Press Home on the remote and pick the original one." ;;
    esac
  fi

  home="$(get_home_app)"
  if [ -n "$home" ] && valid_package "$home" && adb_tv shell pm list packages | grep -qxF "package:$home"; then
    read -r -p "  Also delete the new home screen app from the TV? (y/n): " ans
    case "$ans" in
      y|Y|yes|YES)
        case "$(adb_tv uninstall "$home")" in
          *Success*) ok "Deleted $home" ;;
          *) warn "Couldn't delete $home" ;;
        esac ;;
    esac
  fi

  step "Undo finished."
  log "---- Undo finished"
}

# ---------- menu ----------
while true; do
  clear 2>/dev/null
  say "======================================"
  say "             TV UPDATER"
  say "======================================"
  addr="$(get_setting TV_IP)"
  [ -n "$addr" ] && say "  TV: $addr ($(network_name "$(get_setting TV_NETWORK)"))"
  say ""
  say "  1) Update the TV            <- just press Enter"
  say "  2) Undo - put everything back"
  say "  3) Choose a different TV"
  say "  4) Wi-Fi or Ethernet"
  say "  5) Quit"
  say ""
  read -r -p "  Choose 1-5 (Enter = 1): " choice || exit 0
  [ -z "$choice" ] && choice=1
  case "$choice" in
    1) do_update ;;
    2) do_undo ;;
    3) choose_tv ;;
    4) ask_network ;;
    5|q|Q) exit 0 ;;
    *) continue ;;
  esac
  say ""
  read -r -p "  Press Enter to go back to the menu..." _ || exit 0
done
