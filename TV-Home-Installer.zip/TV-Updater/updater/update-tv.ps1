param([switch]$Auto, [switch]$NoWait, [switch]$UndoAuto)

# TV Updater for Windows. Run it by double-clicking "Update TV (Windows).bat".
# It connects to the Android TV over Wi-Fi, removes the apps listed in
# remove-these-apps.txt, installs/updates the .apk files in the "apps" folder,
# and sets the new home screen. Everything it does can be undone (option 2).

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

$Root       = Split-Path -Parent $PSScriptRoot
$Tools      = $PSScriptRoot
$Settings   = Join-Path $Root 'settings.txt'
$BloatList  = Join-Path $Root 'remove-these-apps.txt'
$AppsDir    = Join-Path $Root 'apps'
$Backups    = Join-Path $Root 'backups'
$RemovedLog = Join-Path $Backups 'removed-apps.txt'
$HomeLog    = Join-Path $Backups 'original-home-screen.txt'
$DisabledLog = Join-Path $Backups 'disabled-launchers.txt'
$RunLog     = Join-Path $Backups 'update-log.txt'

foreach ($d in @($Backups, $AppsDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}
if (-not (Test-Path $RemovedLog)) { New-Item -ItemType File -Path $RemovedLog | Out-Null }

$script:Adb = $null
$script:Serial = $null

try { $Host.UI.RawUI.WindowTitle = 'TV Updater' } catch { }

# ---------- messages ----------
function Write-Log([string]$m) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m
    Add-Content -Path $RunLog -Value $line -Encoding ASCII
}
function Say([string]$m)  { Write-Host $m }
function Ok([string]$m)   { Write-Host '  [OK] ' -ForegroundColor Green -NoNewline; Write-Host $m; Write-Log "OK    $m" }
function Warn([string]$m) { Write-Host '  [!]  ' -ForegroundColor Yellow -NoNewline; Write-Host $m; Write-Log "WARN  $m" }
function Fail([string]$m) { Write-Host '  [X]  ' -ForegroundColor Red -NoNewline; Write-Host $m; Write-Log "FAIL  $m" }
function Step([string]$m) { Write-Host ''; Write-Host $m -ForegroundColor Cyan }

# ---------- settings.txt ----------
function Get-Setting([string]$key) {
    $val = ''
    if (-not (Test-Path $Settings)) { return $val }
    $pattern = '^\s*' + [regex]::Escape($key) + '\s*=(.*)$'
    foreach ($line in Get-Content -Path $Settings) {
        if ($line -match $pattern) { $val = $Matches[1].Trim() }
    }
    return $val
}

# The app that becomes the Home screen: settings.txt's HOME_SCREEN_APP, or TV Home itself when
# that's blank and TV Home is in the apps folder (a blank setting used to skip the step silently).
function Get-HomeApp {
    $h = Get-Setting 'HOME_SCREEN_APP'
    if ($h) { return $h }
    if (Get-ChildItem -Path $AppsDir -Filter '*TVHome*.apk' -ErrorAction SilentlyContinue) { return 'app.tvhome' }
    return ''
}

function Set-Setting([string]$key, [string]$value) {
    $lines = @()
    if (Test-Path $Settings) { $lines = @(Get-Content -Path $Settings) }
    $pattern = '^\s*' + [regex]::Escape($key) + '\s*='
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match $pattern) { $lines[$i] = "$key=$value"; $found = $true }
    }
    if (-not $found) { $lines += "$key=$value" }
    Set-Content -Path $Settings -Value $lines -Encoding ASCII
}

# One package name per line; ignores blank lines and comments.
function Read-List([string]$path) {
    $items = @()
    if (-not (Test-Path $path)) { return $items }
    foreach ($line in Get-Content -Path $path) {
        $l = ($line -replace '#.*$', '').Trim()
        if ($l) { $items += $l }
    }
    return $items
}

# ---------- safety checks ----------
function Test-Package([string]$p) { return ($p -cmatch '^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$') }
function Test-Address([string]$a) { return ($a -match '^[0-9]{1,3}(\.[0-9]{1,3}){3}(:[0-9]{1,5})?$') }

# Never remove anything the TV needs to work, even if it's on the list.
$ProtectedExact = @('android', 'com.android.shell', 'com.android.tv', 'com.android.vending',
                    'com.google.android.gms', 'com.google.android.gsf')
$ProtectedWords = @('launcher', 'inputmethod', 'keyboard', 'setupwizard', 'setupwraith', 'provision',
                    'tvinput', 'tv.input', 'hdmi', 'cec', 'tuner', 'remote', 'bluetooth', 'systemui',
                    'settings', 'providers', 'packageinstaller', 'permissioncontroller', 'webview',
                    'framework', 'mediatek', '.mtk', 'amlogic', 'droidlogic', 'realtek')

function Test-Protected([string]$p) {
    $lp = $p.ToLower()
    if ($ProtectedExact -contains $lp) { return $true }
    foreach ($w in $ProtectedWords) { if ($lp.Contains($w)) { return $true } }
    $homeApp = Get-HomeApp
    if ($homeApp -and ($lp -eq $homeApp.ToLower())) { return $true }
    return $false
}

# ---------- adb ----------
function Find-Adb {
    $local = Join-Path $Tools 'platform-tools\adb.exe'
    if (Test-Path $local) { $script:Adb = $local; return $true }
    $sys = Get-Command 'adb.exe' -ErrorAction SilentlyContinue
    if ($sys) { $script:Adb = $sys.Path; return $true }

    Say '  Downloading the Android tools from Google (one time only)...'
    $zip = Join-Path $Tools 'platform-tools.zip'
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $zip -UseBasicParsing
        Expand-Archive -Path $zip -DestinationPath $Tools -Force
    } catch {
        Fail 'The download failed. Check the internet connection and try again.'
        return $false
    } finally {
        if (Test-Path $zip) { Remove-Item $zip -Force }
    }
    if (Test-Path $local) { $script:Adb = $local; Ok 'Android tools ready'; return $true }
    Fail "Couldn't unpack the Android tools."
    return $false
}

# Runs adb and returns everything it printed as one string.
function Invoke-Adb {
    $out = & $script:Adb @args 2>&1 | ForEach-Object { "$_" }
    return (($out -join "`n") -replace "`r", '')
}
function Invoke-Tv { return (Invoke-Adb -s $script:Serial @args) }

function Get-DeviceState([string]$serial) {
    foreach ($line in ((Invoke-Adb devices) -split "`n")) {
        $parts = $line.Trim() -split '\s+'
        if ($parts.Count -ge 2 -and $parts[0] -eq $serial) { return $parts[1] }
    }
    return ''
}

function Get-LastLine([string]$text) {
    $lines = @($text -split "`n" | Where-Object { $_.Trim() })
    if ($lines.Count -eq 0) { return '' }
    return $lines[$lines.Count - 1].Trim()
}

function Get-NetworkName([string]$n) { if ($n -eq 'ethernet') { return 'an Ethernet cable' } else { return 'Wi-Fi' } }

function Read-Network {
    Say ''
    Say '  How is the TV connected to the internet?'
    Say '    1) Wi-Fi'
    Say '    2) Ethernet cable'
    $c = Read-Host '  Choose 1 or 2'
    if ($c -eq '2') { Set-Setting 'TV_NETWORK' 'ethernet' }
    elseif ($c -eq '1') { Set-Setting 'TV_NETWORK' 'wifi' }
    elseif (-not (Get-Setting 'TV_NETWORK')) { Set-Setting 'TV_NETWORK' 'wifi' }
    Ok "Saved: the TV uses $(Get-NetworkName (Get-Setting 'TV_NETWORK'))"
}

# Which network the connected TV is really using: wifi, ethernet or ''.
function Get-TvNetwork {
    $ip = ($script:Serial -split ':')[0]
    foreach ($line in ((Invoke-Tv shell ip -o -4 addr show) -split "`n")) {
        if ($line.Contains(" $ip/")) {
            if ($line -match 'eth') { return 'ethernet' }
            if ($line -match 'wlan|wifi') { return 'wifi' }
        }
    }
    return ''
}

function Read-Address {
    Say ''
    Say "  Type the TV's IP address. Find it on the TV under"
    if ((Get-Setting 'TV_NETWORK') -eq 'ethernet') {
        Say '  Settings > Network & Internet > Ethernet. It looks like 192.168.1.23'
    } else {
        Say '  Settings > Network & Internet > (your Wi-Fi name). It looks like 192.168.1.23'
    }
    while ($true) {
        $addr = (Read-Host '  TV address') -replace '\s', ''
        if (-not $addr) { return $false }
        if (Test-Address $addr) { Set-Setting 'TV_IP' $addr; Ok 'Saved the TV address'; return $true }
        Warn "That doesn't look right. It should be 4 numbers with dots, like 192.168.1.23"
    }
}

function Pair-Tv {
    Say ''
    Say '  On the TV: Developer options > Wireless debugging > Pair device with pairing code.'
    $paddr = (Read-Host '  Type the IP address and port shown under the code (like 192.168.1.23:37123)') -replace '\s', ''
    $pcode = (Read-Host '  Type the 6-digit code') -replace '\s', ''
    if (-not (Test-Address $paddr) -or ($pcode -notmatch '^[0-9]{6}$')) {
        Fail "That address or code doesn't look right."
        return $false
    }
    if ((Invoke-Adb pair $paddr $pcode) -notmatch 'success') {
        Fail "Pairing didn't work. The code changes each time, so try again with the new one."
        return $false
    }
    Ok 'Paired with the TV'
    Say '  Now look at the main Wireless debugging screen on the TV.'
    $caddr = (Read-Host '  Type the IP address and port shown there (like 192.168.1.23:41234)') -replace '\s', ''
    if (-not (Test-Address $caddr)) { Fail "That address doesn't look right."; return $false }
    Set-Setting 'TV_IP' $caddr
    return $true
}

# This computer's home-network prefixes, like 192.168.1
function Get-LocalPrefixes {
    if ($env:TV_UPDATER_SUBNETS) { return @($env:TV_UPDATER_SUBNETS -split '\s+' | Where-Object { $_ }) }
    $ips = @()
    try {
        $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | ForEach-Object { $_.IPAddress })
    } catch {
        $ips = @([Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) |
            Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.ToString() })
    }
    $prefixes = @()
    foreach ($ip in $ips) {
        if ($ip -match '^((10|172|192)\.\d+\.\d+)\.\d+$' -and $prefixes -notcontains $Matches[1]) { $prefixes += $Matches[1] }
    }
    return @($prefixes | Select-Object -First 4)
}

# Lists TVs that accept a connection: adb's network port 5555, plus newer TVs
# that announce "Wireless debugging". Takes about 2 seconds.
function Find-TvAddresses {
    $names = @(); $clients = @(); $tasks = @()
    foreach ($prefix in (Get-LocalPrefixes)) {
        for ($i = 1; $i -le 254; $i++) {
            $c = New-Object Net.Sockets.TcpClient
            $names += "$prefix.$i"; $clients += $c
            $tasks += $c.ConnectAsync("$prefix.$i", 5555)
        }
    }
    if ($tasks.Count -gt 0) {
        try { $null = [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]$tasks, 2000) } catch { }
    }
    $found = @()
    for ($i = 0; $i -lt $tasks.Count; $i++) {
        if ($tasks[$i].Status -eq 'RanToCompletion') { $found += $names[$i] }
        try { $clients[$i].Close() } catch { }
    }
    foreach ($line in ((Invoke-Adb mdns services) -split "`n")) {
        if ($line -match '_adb-tls-connect' -and $line -match '(\d+\.\d+\.\d+\.\d+:\d+)') {
            $ipOnly = ($Matches[1] -split ':')[0]
            if ($found -notcontains $ipOnly) { $found += $Matches[1] }
        }
    }
    return $found
}

function Get-SerialFor([string]$addr) { if ($addr.Contains(':')) { return $addr } else { return "${addr}:5555" } }

function Get-TvLabel([string]$serial) {
    $shown = $serial -replace ':5555$', ''
    if ((Get-DeviceState $serial) -eq 'device') {
        $name = (Invoke-Adb -s $serial shell settings get global device_name).Trim()
        if (-not $name -or $name -eq 'null') { $name = (Invoke-Adb -s $serial shell getprop ro.product.model).Trim() }
        return "$name  ($shown)"
    }
    return "Android TV at $shown  (press Allow on that TV)"
}

# Finds TVs on the network and saves the one to use. Returns $false if none found.
function Find-Tv {
    Say '  Looking for TVs on your network (a few seconds)...'
    $list = @(Find-TvAddresses)
    if ($list.Count -eq 0) { return $false }
    foreach ($addr in $list) { Invoke-Adb connect (Get-SerialFor $addr) | Out-Null }
    Start-Sleep -Seconds 1
    $labels = @($list | ForEach-Object { Get-TvLabel (Get-SerialFor $_) })
    if ($list.Count -eq 1 -or $Auto -or $UndoAuto) {
        if ($list.Count -gt 1) { Warn "Found $($list.Count) TVs. Using the first one. Run 'Update TV' to pick another." }
        Ok "Found $($labels[0])"
        Set-Setting 'TV_IP' $list[0]
        return $true
    }
    Say ''
    Say "  Found $($list.Count) TVs:"
    for ($i = 0; $i -lt $list.Count; $i++) { Say "    $($i + 1)) $($labels[$i])" }
    while ($true) {
        $choice = Read-Host "  Which TV? (1-$($list.Count))"
        $n = 0
        if ([int]::TryParse($choice, [ref]$n) -and $n -ge 1 -and $n -le $list.Count) {
            Set-Setting 'TV_IP' $list[$n - 1]
            Ok "Using $($labels[$n - 1])"
            return $true
        }
        Warn "Type a number from 1 to $($list.Count)"
    }
}

function Start-Adb {
    if (-not (Find-Adb)) { return $false }
    # Started on its own so the background adb server doesn't hold this window's output.
    $p = Start-Process -FilePath $script:Adb -ArgumentList 'start-server' -NoNewWindow -PassThru
    if ($p) { $null = $p.WaitForExit(20000) }
    return $true
}

function Connect-Serial {
    for ($i = 0; $i -lt 3; $i++) {
        Invoke-Adb connect $script:Serial | Out-Null
        $state = Get-DeviceState $script:Serial
        if ($state -and $state -ne 'offline') { return $state }
        Invoke-Adb disconnect $script:Serial | Out-Null
        Start-Sleep -Seconds 1
    }
    return ''
}

function Connect-Tv {
    if (-not (Start-Adb)) { return $false }
    while ($true) {
        $state = ''
        $addr = Get-Setting 'TV_IP'
        if ($addr) {
            $script:Serial = Get-SerialFor $addr
            Say "  Connecting to the TV at $($script:Serial -replace ':5555$', '')..."
            $state = Connect-Serial
        }
        if (-not $state -or $state -eq 'offline') {
            if (Find-Tv) {
                $script:Serial = Get-SerialFor (Get-Setting 'TV_IP')
                $state = Connect-Serial
            }
        }

        if ($state -eq 'unauthorized' -or $state -eq 'authorizing') {
            Say ''
            Say '  >> Look at the TV now. It should ask "Allow USB debugging?"'
            Say '     Tick "Always allow from this computer" and press OK.'
            Say '     (Waiting up to 2 minutes...)'
            for ($i = 0; $i -lt 60; $i++) {
                Start-Sleep -Seconds 2
                $state = Get-DeviceState $script:Serial
                if ($state -eq 'device') { break }
                if (-not $state) { Invoke-Adb connect $script:Serial | Out-Null }
            }
        }

        if ($state -eq 'device') { Ok 'Connected to the TV'; return $true }

        Say ''
        Fail "Couldn't find a TV that's ready."
        Say '  On the TV: turn on Developer options, then USB debugging'
        Say "  (and Network debugging if it's there). See the Setup Guide."
        Say '  The TV and this computer must be on the same home network.'
        Say ''
        if ($Auto -or $UndoAuto) { return $false }
        Say '    1) Look again'
        Say "    2) Type the TV's IP address"
        Say "    3) Pair using a code (newer TVs with 'Wireless debugging')"
        Say '    4) Go back'
        $choice = Read-Host '  Choose 1-4'
        switch ($choice) {
            '1' { Set-Setting 'TV_IP' '' }
            '2' { if (-not (Read-Address)) { return $false } }
            '3' { if (-not (Pair-Tv)) { return $false } }
            default { return $false }
        }
    }
}

function Select-Tv {
    if (-not (Start-Adb)) { return }
    if (-not (Find-Tv)) {
        Warn 'No TVs found. Check the TV is on and set up (see the Setup Guide).'
        Read-Address | Out-Null
    }
}

function Resolved-Home {
    # Package name of whatever currently answers the Home button, or '' if none.
    $c = Get-LastLine (Invoke-Adb -s $script:Serial shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME)
    if ($c -match '^([A-Za-z0-9_.]+)/') { return $Matches[1] }
    return ''
}

function Test-Installed([string]$pkg) {
    $list = (Invoke-Tv shell pm list packages) -split "`n"
    return ($list -contains "package:$pkg")
}

# Saves the Wi-Fi/Ethernet choice on the TV for TV Home to read.
function Save-Choices {
    $setupFile = Join-Path $Backups 'tvhome-setup.json'
    $json = '{"tvNetwork":"' + (Get-Setting 'TV_NETWORK') + '","savedBy":"TV Updater","savedAt":"' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss') + '"}'
    [IO.File]::WriteAllText($setupFile, $json + "`n")
    Invoke-Tv shell mkdir -p /sdcard/TVHome | Out-Null
    if ((Invoke-Tv push $setupFile /sdcard/TVHome/setup.json) -match 'error|failed') {
        Warn "Couldn't save the settings file on the TV. TV Home will ask instead."
    } else {
        Ok "TV Home will set game streaming for $(Get-NetworkName (Get-Setting 'TV_NETWORK'))"
    }
    if ((Get-Setting 'TV_NETWORK') -ne 'ethernet') {
        Say '  Tip: for smooth game streaming, use 5 GHz Wi-Fi or plug the TV in with a cable.'
    }
}

# ---------- the jobs ----------
function Start-Update {
    if (-not (Get-Setting 'TV_NETWORK')) { if ($Auto) { Set-Setting 'TV_NETWORK' 'wifi' } else { Read-Network } }
    Step 'Step 1 of 6: Connecting'
    if (-not (Connect-Tv)) { return }
    $model = (Invoke-Tv shell getprop ro.product.model).Trim()
    $android = (Invoke-Tv shell getprop ro.build.version.release).Trim()
    Ok "TV model: $model (Android $android)"
    $net = Get-TvNetwork
    if ($net -and $net -ne (Get-Setting 'TV_NETWORK')) {
        Warn "The TV is actually using $(Get-NetworkName $net), so I've changed that setting."
        Set-Setting 'TV_NETWORK' $net
    }
    Ok "The TV is connected by $(Get-NetworkName (Get-Setting 'TV_NETWORK'))"
    Write-Log "---- Update started on $model (Android $android) at $($script:Serial)"

    Step 'Step 2 of 6: Backing up the app list'
    $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $installedFile = Join-Path $Backups "apps-before-$stamp.txt"
    $installed = @(((Invoke-Tv shell pm list packages) -split "`n") |
        Where-Object { $_ -like 'package:*' } |
        ForEach-Object { $_.Substring(8).Trim() } | Sort-Object)
    if ($installed.Count -eq 0) {
        Fail "Couldn't read the TV's app list, so nothing was changed."
        return
    }
    Set-Content -Path $installedFile -Value $installed -Encoding ASCII
    Ok "Saved a list of $($installed.Count) apps to backups\apps-before-$stamp.txt"

    $changed = $false
    $hasApks = @(Get-ChildItem -Path $AppsDir -Filter '*.apk' -File -ErrorAction SilentlyContinue).Count -gt 0
    if (-not $hasApks -and @(Read-List $BloatList).Count -eq 0) {
        Save-Choices
        Step "This TV is ready, but there's nothing to install yet"
        Say '  The apps folder is empty and no junk apps are listed, so nothing on the TV was changed.'
        Say '  When you get the TV Home app (an .apk file), put it in the apps folder'
        Say '  and run this again. It will install it and make it the home screen.'
        Write-Log '---- Nothing to install yet'
        return
    }

    Step 'Step 3 of 6: Removing junk apps'
    $bloat = @(Read-List $BloatList)
    if ($bloat.Count -eq 0) {
        Say '  No apps are listed in remove-these-apps.txt, so nothing to remove.'
    } else {
        $removed = 0; $skipped = 0; $gone = 0
        $already = @(Read-List $RemovedLog)
        foreach ($pkg in $bloat) {
            if (-not (Test-Package $pkg)) { Warn "Skipped `"$pkg`" - that isn't a valid app name"; $skipped++; continue }
            if (Test-Protected $pkg) { Warn "Kept $pkg - the TV needs it"; $skipped++; continue }
            if ($installed -notcontains $pkg) { $gone++; continue }
            $out = Invoke-Tv shell pm uninstall -k --user 0 $pkg
            if ($out -match 'Success') {
                Ok "Removed $pkg"; $removed++; $changed = $true
                if ($already -notcontains $pkg) { Add-Content -Path $RemovedLog -Value $pkg -Encoding ASCII; $already += $pkg }
            } else {
                Warn "Couldn't remove $pkg ($out)"; $skipped++
            }
        }
        Say "  Removed $removed, already gone $gone, skipped $skipped."
    }

    Step 'Step 4 of 6: Installing and updating apps'
    $apks = @(Get-ChildItem -Path $AppsDir -Filter '*.apk' -File -ErrorAction SilentlyContinue)
    if ($apks.Count -eq 0) {
        Say '  There are no .apk files in the apps folder, so nothing to install.'
    } else {
        foreach ($apk in $apks) {
            $name = $apk.Name
            Say "  Installing $name (this can take a minute)..."
            $out = Invoke-Tv install -r -d $apk.FullName
            if ($out -match 'Success') { Ok "Installed $name"; $changed = $true; continue }
            $code = ''
            if ($out -match '(INSTALL_[A-Z_]+)') { $code = $Matches[1] }
            switch ($code) {
                'INSTALL_FAILED_UPDATE_INCOMPATIBLE' {
                    Warn "$name was built on a different computer than the copy already on the TV."
                    if ($out -match 'Existing package ([A-Za-z0-9_.]+) signatures') {
                        $existing = $Matches[1]
                        if ($Auto) { $ans = 'n'; Say '  Run Update TV to replace it (its settings would be reset).' } else { $ans = Read-Host '  Remove the old copy and install this one? Its settings, like the camera login, will need setting up again. (y/n)' }
                        if ($ans -match '^(y|yes)$') {
                            Invoke-Tv uninstall $existing | Out-Null
                            $out = Invoke-Tv install -r $apk.FullName
                            if ($out -match 'Success') { Ok "Installed $name"; $changed = $true } else { Fail "Still couldn't install $name ($out)" }
                        } else {
                            Warn "Left the old copy of $name on the TV"
                        }
                    }
                }
                'INSTALL_FAILED_VERSION_DOWNGRADE'    { Warn "The TV already has a newer version of $name, so it was kept." }
                'INSTALL_FAILED_INSUFFICIENT_STORAGE' { Fail "The TV is out of space, so $name couldn't be installed." }
                'INSTALL_FAILED_NO_MATCHING_ABIS'     { Fail "$name wasn't built for this TV's processor." }
                'INSTALL_FAILED_OLDER_SDK'            { Fail "This TV's Android version is too old for $name." }
                default                               { Fail "Couldn't install $name ($out)" }
            }
        }
    }

    Step 'Step 5 of 6: Setting the home screen'
    $homeApp = Get-HomeApp
    $componentPattern = '^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$'
    if (-not $homeApp) {
        Say '  No home screen app is set in settings.txt, so this step was skipped.'
    } elseif (-not (Test-Package $homeApp)) {
        Warn "HOME_SCREEN_APP in settings.txt isn't a valid app name, so this step was skipped."
    } elseif (-not (Test-Installed $homeApp)) {
        Warn "The home screen app ($homeApp) isn't on the TV yet. Put its .apk in the apps folder."
    } else {
        # Lets the camera alerts appear over other apps.
        Invoke-Tv shell appops set $homeApp SYSTEM_ALERT_WINDOW allow | Out-Null
        # Music screen: see what's playing in other apps (YouTube, Spotify...)
        if ($homeApp -eq 'app.tvhome') { Invoke-Tv shell cmd notification allow_listener app.tvhome/app.tvhome.MediaListener | Out-Null }
        # TV Home's Sound settings can switch surround sound off (films with a soundbar) and frame-rate matching.
        if ($homeApp -eq 'app.tvhome') { Invoke-Tv shell pm grant app.tvhome android.permission.WRITE_SECURE_SETTINGS | Out-Null }
        # All files access: game files, save backups, and the folder picker for PPSSPP / Lemuroid on Google TV.
        if ($homeApp -eq 'app.tvhome') { Invoke-Tv shell appops set --uid app.tvhome MANAGE_EXTERNAL_STORAGE allow | Out-Null }
        # Problem reports (Settings > TV Home): lets TV Home read the TV's recent log when asked.
        if ($homeApp -eq 'app.tvhome') { Invoke-Tv shell pm grant app.tvhome android.permission.READ_LOGS | Out-Null }
        Invoke-Tv shell pm grant $homeApp android.permission.READ_EXTERNAL_STORAGE | Out-Null
        Invoke-Tv shell appops set $homeApp REQUEST_INSTALL_PACKAGES allow | Out-Null
        Invoke-Tv shell appops set $homeApp MANAGE_EXTERNAL_STORAGE allow | Out-Null
        Ok 'Allowed camera alerts, USB drive access and self-updates'

        if (-not ((Test-Path $HomeLog) -and (Get-Content $HomeLog))) {
            $cur = Get-LastLine (Invoke-Tv shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME)
            if (($cur -match $componentPattern) -and -not $cur.StartsWith('android/') -and -not $cur.StartsWith("$homeApp/")) {
                Set-Content -Path $HomeLog -Value $cur -Encoding ASCII
            }
        }

        $comp = Get-LastLine (Invoke-Tv shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME $homeApp)
        if ($comp -notmatch $componentPattern) {
            Warn "Couldn't find a home screen inside $homeApp. Press Home on the remote and pick it from the list."
        } else {
            Invoke-Tv shell cmd package set-home-activity "'$comp'" | Out-Null
            if ((Resolved-Home) -eq $homeApp) {
                Ok 'The new home screen is now the default'; $changed = $true
            } else {
                # Google TV / newer TVs ignore the setting and keep their own launcher in front.
                # Switch off whatever is currently acting as Home (one at a time) until TV Home wins.
                Say '  This TV keeps its own home screen in front. Switching it off so TV Home can take over...'
                $disabled = @(Read-List $DisabledLog)
                $justDisabled = @()
                for ($i = 0; $i -lt 4; $i++) {
                    $hp = Resolved-Home
                    if ($hp -eq $homeApp) { break }
                    if (-not $hp -or $hp -eq 'android' -or $hp -eq $homeApp) { break }
                    Invoke-Tv shell pm disable-user --user 0 $hp | Out-Null
                    $justDisabled += $hp
                    if ($disabled -notcontains $hp) { $disabled += $hp }
                    Invoke-Tv shell cmd package set-home-activity "'$comp'" | Out-Null
                }
                if ((Resolved-Home) -eq $homeApp) {
                    Set-Content -Path $DisabledLog -Value $disabled -Encoding ASCII
                    Ok 'TV Home is now the home screen'; $changed = $true
                } else {
                    # Rollback: re-enable anything we just switched off, so the TV keeps a working home screen.
                    foreach ($hp in $justDisabled) { Invoke-Tv shell pm enable $hp | Out-Null }
                    Warn "This TV wouldn't let TV Home take over the Home button, so its own home screen was kept. TV Home is still installed under Apps."
                }
            }
        }
    }

    Step 'Step 6 of 6: Saving your choices on the TV'
    Save-Choices

    if ($changed) {
        Step 'All done!'
        Say '  Press Home on the TV remote to see the result.'
        Say '  If anything looks wrong, run this again and choose 2) Undo.'
    } else {
        Step 'Finished. Nothing on the TV needed changing.'
    }
    Write-Log '---- Update finished'
}

function Start-Undo {
    Step 'Undo: putting the TV back how it was'
    if (-not (Connect-Tv)) { return }
    Write-Log "---- Undo started at $($script:Serial)"

    $removed = @(Read-List $RemovedLog)
    if ($removed.Count -eq 0) {
        Say "  This updater hasn't removed any apps, so there's nothing to put back."
    } else {
        $kept = @()
        foreach ($pkg in $removed) {
            if (-not (Test-Package $pkg)) { continue }
            $out = Invoke-Tv shell pm install-existing $pkg
            if (($out -notmatch 'Failure|Error|exist') -and ($out -match 'installed|Success')) {
                Ok "Put back $pkg"
            } else {
                Warn "Couldn't put back $pkg ($out)"; $kept += $pkg
            }
        }
        if ($kept.Count -gt 0) {
            Set-Content -Path $RemovedLog -Value $kept -Encoding ASCII
        } else {
            [IO.File]::WriteAllText($RemovedLog, '')
        }
    }

    foreach ($hp in @(Read-List $DisabledLog)) {
        Invoke-Tv shell pm enable $hp | Out-Null
        Ok "Switched $hp back on"
    }
    if (Test-Path $DisabledLog) { Remove-Item $DisabledLog -Force }

    if ((Test-Path $HomeLog) -and (Get-Content $HomeLog)) {
        $orig = (Get-Content $HomeLog | Select-Object -First 1).Trim()
        $out = Invoke-Tv shell cmd package set-home-activity "'$orig'"
        if ($out -match 'Success') {
            Ok 'Switched back to the original home screen'
            Remove-Item $HomeLog -Force
        } else {
            Warn "Couldn't switch the home screen back. Press Home on the remote and pick the original one."
        }
    }

    $homeApp = Get-HomeApp
    if ($homeApp -and (Test-Package $homeApp) -and (Test-Installed $homeApp)) {
        if ($UndoAuto) { $ans = 'y' } else { $ans = Read-Host '  Also delete the new home screen app from the TV? (y/n)' }
        if ($ans -match '^(y|yes)$') {
            if ((Invoke-Tv uninstall $homeApp) -match 'Success') { Ok "Deleted $homeApp" } else { Warn "Couldn't delete $homeApp" }
        }
    }

    Step 'Undo finished.'
    Write-Log '---- Undo finished'
}

# ---------- menu ----------
if ($Auto) {
    Start-Update
    if (-not $NoWait) {
        Say ''
        Say '  This window closes by itself in 60 seconds.'
        Start-Sleep -Seconds 60
    }
    exit 0
}
if ($UndoAuto) {
    Start-Undo
    exit 0
}

:menu while ($true) {
    try { Clear-Host } catch { }
    Say '======================================'
    Say '             TV UPDATER'
    Say '======================================'
    $addr = Get-Setting 'TV_IP'
    if ($addr) { Say "  TV: $addr ($(Get-NetworkName (Get-Setting 'TV_NETWORK')))" }
    Say ''
    Say '  1) Update the TV            <- just press Enter'
    Say '  2) Undo - put everything back'
    Say '  3) Choose a different TV'
    Say '  4) Wi-Fi or Ethernet'
    Say '  5) Quit'
    Say ''
    $choice = Read-Host '  Choose 1-5 (Enter = 1)'
    if ($null -eq $choice) { break }
    if ($choice.Trim() -eq '') { $choice = '1' }
    switch ($choice.Trim()) {
        '1' { Start-Update }
        '2' { Start-Undo }
        '3' { Select-Tv }
        '4' { Read-Network }
        '5' { exit 0 }
        'q' { exit 0 }
        default { continue menu }
    }
    Say ''
    $null = Read-Host '  Press Enter to go back to the menu'
}
exit 0
