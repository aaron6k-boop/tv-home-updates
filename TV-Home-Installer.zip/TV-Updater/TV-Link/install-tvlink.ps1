# Installs TV Link for this Windows user: copies it, starts it with Windows (hidden), opens ports 8787 and 8790 (cameras)
# to devices on the local network only, and turns on Wake-on-LAN for the network card. Asks once for
# admin (Yes/No box). -NoWait skips the closing pause (used by "Install TV Home > Set up this PC").
param([switch]$NoWait)
$ErrorActionPreference = 'Continue'
$src = $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA 'TVLink'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $src 'TVLink.ps1') $dest -Force

# Hidden launcher so no window stays open
$vbs = Join-Path $dest 'run-hidden.vbs'
$cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $dest 'TVLink.ps1') + '"'
Set-Content -Path $vbs -Value ('CreateObject("WScript.Shell").Run "' + $cmd.Replace('"', '""') + '", 0, False') -Encoding ASCII

# Start with Windows
$startup = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $startup 'TV Link.lnk'
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = 'wscript.exe'
$s.Arguments = '"' + $vbs + '"'
$s.WorkingDirectory = $dest
$s.Description = 'TV Link for TV Home'
$s.Save()
Write-Host '[OK] TV Link will start with Windows'

# Admin bits: firewall rule (home network only) and Wake-on-LAN on the network card
$admin = @'
netsh advfirewall firewall delete rule name="TV Link" | Out-Null
netsh advfirewall firewall add rule name="TV Link" dir=in action=allow protocol=TCP localport=8787,8790 profile=any remoteip=localsubnet | Out-Null
try {
  $cfg = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } | Select-Object -First 1
  if ($cfg) {
    $name = $cfg.NetAdapter.Name
    Get-NetAdapterAdvancedProperty -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'Wake on Magic Packet|Wake on magic packet|WOL & Shutdown Link Speed' -and $_.DisplayName -notmatch 'Speed' } | ForEach-Object {
      Set-NetAdapterAdvancedProperty -Name $name -DisplayName $_.DisplayName -DisplayValue 'Enabled' -ErrorAction SilentlyContinue }
    $pnp = $cfg.NetAdapter.InterfaceDescription
    powercfg /deviceenablewake "$pnp" | Out-Null
  }
} catch { }
'@
$tmp = Join-Path $env:TEMP 'tvlink-admin.ps1'
Set-Content -Path $tmp -Value $admin -Encoding UTF8
Write-Host '  Windows will ask for permission (click Yes) to let the TV reach this PC and to turn on Wake-on-LAN.'
try {
    Start-Process powershell.exe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$tmp`"") -Verb RunAs -Wait
    Write-Host '[OK] The TV can now reach this PC (home network only), Wake-on-LAN turned on'
} catch {
    Write-Host '[!]  Skipped. If the TV can''t find your PC, run this again and click Yes.'
}

# Make sure the current network is "Private" so the TV can reach the PC
try {
    $prof = Get-NetConnectionProfile | Where-Object { $_.IPv4Connectivity -eq 'Internet' } | Select-Object -First 1
    if ($prof -and $prof.NetworkCategory -ne 'Private') {
        Write-Host '[!]  Your network is set to Public. In Windows Settings > Network, set it to Private so the TV can find this PC.'
    }
} catch { }

# Start it now
# Stop any TV Link already running, wherever it was started from (an older copy in Downloads, say),
# so the new one can use the port.
Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match '[\\/"\s]TVLink\.ps1' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
try { Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object {
    $p = Get-Process -Id $_ -ErrorAction SilentlyContinue
    if ($p -and $p.ProcessName -match '^(powershell|pwsh)$' -and $_ -ne $PID) { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue } } } catch { }
Start-Sleep -Milliseconds 800
Start-Process wscript.exe -ArgumentList ('"' + $vbs + '"')
Write-Host '[OK] TV Link is running. TV Home finds it automatically.'
Write-Host ''
Write-Host 'For waking the PC from the TV, also turn on "Wake on LAN" (or "Power on by PCIe") in your PC''s BIOS.'
if (-not $NoWait) {
    Write-Host 'This window closes in 20 seconds.'
    Start-Sleep -Seconds 20
}
