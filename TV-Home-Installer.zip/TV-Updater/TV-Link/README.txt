TV LINK (for your PC)
=====================

Lets TV Home on your TVs:
- show this PC's CPU, GPU, RAM and storage on the home screen
- use your Wallpaper Engine wallpapers (and set them on the PC too)
- wake this PC for game streaming

Install: double-click "Install TV Link.bat" and click Yes when Windows asks.
It starts with Windows and runs hidden. It only answers on your home network (port 8787).

Remove: delete "TV Link" from your Startup folder (Win+R, type shell:startup)
and the folder %LOCALAPPDATA%\TVLink.
