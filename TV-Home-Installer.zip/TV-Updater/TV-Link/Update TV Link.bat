@echo off
title Update TV Link
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-tvlink.ps1"
