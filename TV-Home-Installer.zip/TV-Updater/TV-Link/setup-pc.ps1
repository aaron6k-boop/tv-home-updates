# Sets up this Windows PC so TV Home on the TV finds it by itself:
#   1. TV Link  - PC stats on the TV, Wallpaper Engine, waking the PC from the TV
#   2. Sunshine - streams PC games to Moonlight on the TV (free, from LizardByte)
# Run from "Install TV Home" (button: Set up this PC) or on its own. Prints [OK]/[!]/[X] lines.
param([switch]$NoWait)
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
$here = $PSScriptRoot

function Test-Sunshine {
    if (Get-Service -Name 'SunshineService', 'sunshinesvc' -ErrorAction SilentlyContinue) { return $true }
    foreach ($p in @("$env:ProgramFiles\Sunshine\sunshine.exe", "${env:ProgramFiles(x86)}\Sunshine\sunshine.exe")) { if ($p -and (Test-Path $p)) { return $true } }
    return $false
}

Write-Host 'Step 1 of 3: Setting up TV Link (stats, wallpapers, wake from the TV)'
& (Join-Path $here 'install-tvlink.ps1') -NoWait

Write-Host 'Step 2 of 3: Setting up game streaming (Sunshine)'
if (Test-Sunshine) {
    Write-Host '[OK] Sunshine is already on this PC'
} else {
    $done = $false
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host '  Downloading Sunshine (free). If Windows asks for permission, click Yes.'
        try {
            $p = Start-Process winget.exe -ArgumentList @('install', '--id', 'LizardByte.Sunshine', '-e', '--silent', '--accept-source-agreements', '--accept-package-agreements') -Wait -PassThru -WindowStyle Hidden
            Start-Sleep -Seconds 2
            $done = Test-Sunshine
        } catch { }
    }
    if (-not $done) {
        Write-Host '  Getting Sunshine from its official download page...'
        try {
            $rel = Invoke-RestMethod 'https://api.github.com/repos/LizardByte/Sunshine/releases/latest' -Headers @{ 'User-Agent' = 'TVHome' }
            $asset = $rel.assets | Where-Object { $_.name -match 'Windows-AMD64-installer\.msi$' } | Select-Object -First 1
            if (-not $asset) { $asset = $rel.assets | Where-Object { $_.name -match '(?i)windows.*installer.*\.(msi|exe)$' } | Select-Object -First 1 }
            if ($asset) {
                $file = Join-Path $env:TEMP $asset.name
                Invoke-WebRequest $asset.browser_download_url -OutFile $file -UseBasicParsing
                Write-Host '  Installing Sunshine. Windows will ask for permission, click Yes.'
                if ($file -match '\.msi$') { Start-Process msiexec.exe -ArgumentList @('/i', "`"$file`"", '/qn', '/norestart') -Verb RunAs -Wait }
                else { Start-Process $file -ArgumentList '/S' -Verb RunAs -Wait }
                Start-Sleep -Seconds 2
                $done = Test-Sunshine
            }
        } catch { }
    }
    if ($done) { Write-Host '[OK] Sunshine installed' }
    else { Write-Host '[!] Couldn''t install Sunshine automatically. Get it free from lizardbyte.dev/sunshine, then run this again.' }
}

Write-Host 'Step 3 of 3: Finishing'
$name = $env:COMPUTERNAME
Write-Host "[OK] This PC ($name) is set up. Your TV finds it by itself - it shows at the top of TV Home."
if (Test-Sunshine) {
    Write-Host '[!] One time only, for games: in the Sunshine page that opens, make a username and password.'
    Write-Host '[!] Then on the TV choose Play PC Games, pick this PC, and type the PIN it shows into that Sunshine page.'
    Write-Host '[!] If your browser warns about the page, choose Advanced > Continue - it''s your own PC.'
    try { Start-Process 'https://localhost:47990' } catch { }
}
Write-Host 'All done!'
if (-not $NoWait) { Start-Sleep -Seconds 20 }
