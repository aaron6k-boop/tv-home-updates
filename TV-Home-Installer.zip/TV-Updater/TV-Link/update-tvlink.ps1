# Updates TV Link without asking Windows for admin: copies the new TV Link into place and restarts it.
# (The network permission and start-with-Windows from the first install stay as they are.)
$ErrorActionPreference = 'Continue'
$d = Join-Path $env:LOCALAPPDATA 'TVLink'
New-Item -ItemType Directory -Force -Path $d | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'TVLink.ps1') -Destination $d -Force
$vbs = Join-Path $d 'run-hidden.vbs'
if (-not (Test-Path -LiteralPath $vbs)) {
    $cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $d 'TVLink.ps1') + '"'
    Set-Content -Path $vbs -Value ('CreateObject("WScript.Shell").Run "' + $cmd.Replace('"', '""') + '", 0, False') -Encoding ASCII
}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match '[\\/"\s]TVLink\.ps1' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800
Start-Process wscript.exe -ArgumentList ('"' + $vbs + '"')
Write-Host '[OK] TV Link is updated and running. This window closes by itself.'
Start-Sleep -Seconds 4
