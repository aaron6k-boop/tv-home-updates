@echo off
title TV Updater
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0updater\update-tv.ps1"
if errorlevel 1 pause
